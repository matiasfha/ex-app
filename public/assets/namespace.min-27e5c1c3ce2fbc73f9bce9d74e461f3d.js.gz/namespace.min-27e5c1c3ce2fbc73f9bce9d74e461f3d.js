/*
 * namespace.coffee v1.0.1
 * Copyright (c) 2011-2012 CodeCatalyst, LLC.
 * Open source under the MIT License.
 */
(function(){var e;e=function(e,t){var n,r,i,s,o,u;i="undefined"!=typeof exports&&null!==exports?exports:window;if(0<e.length){u=e.split("."),s=0;for(o=u.length;s<o;s++)r=u[s],i=i[r]||(i[r]={})}for(n in t)r=t[n],i[n]=r;return i},e("",{namespace:e})}).call(this);